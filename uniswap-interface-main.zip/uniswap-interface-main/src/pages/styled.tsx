import styled from 'styled-components'

export const StandardPageWrapper = styled.div`
  padding-top: 160px;
  width: 100%;
`
