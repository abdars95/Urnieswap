import { addons } from '@storybook/addons'
import { light } from './theme'

addons.setConfig({ theme: light })
